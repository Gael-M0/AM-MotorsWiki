import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:isar/isar.dart';
import '../modelsp1/vehiculo.dart';
import '../providers/favoritos_provider.dart';

class VehiculosScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final isar = Provider.of<FavoritosProvider>(context, listen: false).isar;
    final userId = 1;

    return FutureBuilder<List<Vehiculo>>(
      future: isar.vehiculos.where().findAll(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final vehiculos = snapshot.data!;

        return Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.black,
            iconTheme: const IconThemeData(color: Colors.white),
            title: const Text(
              'Inspeccionar',
              style: TextStyle(color: Colors.white),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.star, color: Colors.yellow),
                onPressed: () => Navigator.pushNamed(context, '/favoritos'),
              ),
              IconButton(
                icon: const Icon(Icons.person, color: Colors.white),
                onPressed: () => Navigator.pushNamed(context, '/registro'),
              ),
            ],
          ),
          body: ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: vehiculos.length,
            itemBuilder: (context, index) {
              final vehiculo = vehiculos[index];
              final favoritosProvider = Provider.of<FavoritosProvider>(context);

              return GestureDetector(
                onTap: () => Navigator.pushNamed(
                  context,
                  '/descripcion',
                  arguments: vehiculo,
                ),
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 10.0),
                  padding: const EdgeInsets.all(10.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Image.network(
                        vehiculo.imagen,
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              vehiculo.nombre,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              vehiculo.descripcion,
                              style: const TextStyle(fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          favoritosProvider.favoritos.any((fav) => fav.id == vehiculo.id)
                              ? Icons.star
                              : Icons.star_border,
                          color: favoritosProvider.favoritos.any((fav) => fav.id == vehiculo.id)
                              ? Colors.black
                              : null,
                        ),
                        onPressed: () async {
                          if (favoritosProvider.favoritos.any((fav) => fav.id == vehiculo.id)) {
                            await favoritosProvider.eliminarDeFavoritos(vehiculo, userId);
                          } else {
                            await favoritosProvider.agregarAFavoritos(vehiculo, userId);
                          }
                          // Refrescar la lista de favoritos
                          favoritosProvider.notifyListeners();
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}